# 카드콕 Android 수정 프로젝트 v1.1

기존 Streamlit 카드콕 웹앱을 Android WebView로 표시하는 앱입니다.
이번 수정은 Kotlin Android 플러그인을 명시해 Activity 코드가 APK에 실제로 컴파일되도록 한 것입니다.

## GitHub 반영
1. 이 ZIP 파일을 내려받습니다.
2. 기존 저장소의 `card-cock-android.zip`을 새 파일로 교체(같은 이름으로 업로드 및 덮어쓰기)합니다.
3. Commit changes를 누릅니다.
4. Actions에서 새 빌드가 실행되는지 확인합니다.
5. 성공한 실행의 Artifacts에서 `card-cock-debug-apk`를 내려받습니다.
6. 기존 카드콕 앱을 삭제한 뒤 새 APK를 설치합니다.

웹앱 URL은 `MainActivity.kt`의 appUrl에 지정되어 있습니다. 실제 배포 주소가 다르면 이 주소를 수정해야 합니다.
직접 설치 APK이므로 Android 보안 경고가 표시될 수 있습니다. 보호 기능을 무조건 끄지 말고, 신뢰할 수 있는 본인이 만든 빌드인지 확인하세요.
