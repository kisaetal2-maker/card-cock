# 카드콕 안드로이드 앱
기존 Streamlit 웹앱을 표시하는 Android WebView 앱입니다. 카드 혜택 계산 및 기록은 기존 웹앱에서 처리됩니다.

## 빌드 방법
1. 이 ZIP 파일을 기존 GitHub 저장소 최상위에 `card-cock-android.zip` 이름으로 업로드합니다.
2. GitHub에서 Add file → Create new file을 선택합니다.
3. 파일명을 `.github/workflows/build-android.yml`로 입력합니다.
4. ZIP 안의 `GITHUB_WORKFLOW_TO_COPY.txt` 내용을 붙여넣고 Commit합니다.
5. Actions 탭에서 `Build CardCock Android APK`를 실행합니다.
6. 완료된 실행 결과의 Artifacts에서 `card-cock-debug-apk`를 내려받아 압축을 풀면 APK가 있습니다.

주의: 직접 설치 APK는 Play 스토어 앱이 아니므로 Android/Play Protect가 경고할 수 있습니다. 보안 경고를 무조건 무시하거나 보호 기능을 끄지 마세요. 앱 설치가 막히면 Chrome의 홈 화면 추가 기능을 사용하세요.
